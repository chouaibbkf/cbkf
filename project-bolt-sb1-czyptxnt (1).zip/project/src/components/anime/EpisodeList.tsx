import React from 'react';
import { Play, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Episode } from '../../types';

interface EpisodeListProps {
  animeId: number;
  episodes: Episode[];
  className?: string;
}

export const EpisodeList: React.FC<EpisodeListProps> = ({ animeId, episodes, className = '' }) => {
  return (
    <div className={className}>
      <h3 className="text-xl font-bold mb-4">Episodes</h3>
      <div className="space-y-4">
        {episodes.map((episode) => (
          <Link 
            key={episode.id}
            to={`/watch/${animeId}/${episode.number}`}
            className="block group"
          >
            <div className="flex flex-col sm:flex-row bg-gray-800 rounded-lg overflow-hidden transition-colors hover:bg-gray-700">
              <div className="relative sm:w-48 h-32">
                <img 
                  src={episode.thumbnail} 
                  alt={`Episode ${episode.number}`}
                  className="w-full h-full object-cover" 
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 rounded-full bg-primary-600/90 flex items-center justify-center">
                    <Play className="h-6 w-6 text-white" fill="white" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/70 text-xs font-medium rounded">
                  {episode.duration}
                </div>
              </div>
              
              <div className="p-4 flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold">
                      Episode {episode.number} - {episode.title}
                    </h4>
                    <div className="flex items-center mt-2 text-sm text-gray-400">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Released: {episode.releaseDate}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};