import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Menu, X, User, Heart, Clock, Moon, Sun, MonitorPlay } from 'lucide-react';
import { Button } from '../ui/Button';
import { useTheme } from '../../context/ThemeContext';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { isDarkMode, toggleTheme } = useTheme();
  const location = useLocation();
  
  // Handle scrolling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsSearchOpen(false);
  }, [location]);
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Navigate to search page with query
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
      setSearchQuery('');
      setIsSearchOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-gray-900/95 backdrop-blur-sm shadow-md' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <MonitorPlay className="h-8 w-8 text-primary-500" />
            <span className="text-xl font-bold text-white">AniBKF</span>
          </Link>
          
          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-sm font-medium hover:text-primary-400 transition-colors">
              Home
            </Link>
            <Link to="/browse" className="text-sm font-medium hover:text-primary-400 transition-colors">
              Browse
            </Link>
            <Link to="/genres" className="text-sm font-medium hover:text-primary-400 transition-colors">
              Genres
            </Link>
            <Link to="/popular" className="text-sm font-medium hover:text-primary-400 transition-colors">
              Popular
            </Link>
          </nav>
          
          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 rounded-full hover:bg-gray-800 transition-colors"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </button>
            
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-800 transition-colors"
              aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            
            <Link to="/watchlist">
              <button
                className="p-2 rounded-full hover:bg-gray-800 transition-colors"
                aria-label="Watchlist"
              >
                <Heart className="h-5 w-5" />
              </button>
            </Link>
            
            <Link to="/history">
              <button
                className="p-2 rounded-full hover:bg-gray-800 transition-colors"
                aria-label="History"
              >
                <Clock className="h-5 w-5" />
              </button>
            </Link>
            
            <Link to="/login">
              <Button 
                variant="primary" 
                size="sm"
                leftIcon={<User className="h-4 w-4" />}
              >
                Sign In
              </Button>
            </Link>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden space-x-3">
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 rounded-full hover:bg-gray-800 transition-colors"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </button>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-full hover:bg-gray-800 transition-colors"
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Search Overlay */}
      {isSearchOpen && (
        <div className="absolute inset-x-0 top-16 bg-gray-900/95 backdrop-blur-sm shadow-md p-4">
          <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search anime..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                <X className="h-5 w-5 text-gray-400 hover:text-white" />
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-gray-900/95 backdrop-blur-sm">
          <div className="px-4 py-3 space-y-1">
            <Link
              to="/"
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-800"
            >
              Home
            </Link>
            <Link
              to="/browse"
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-800"
            >
              Browse
            </Link>
            <Link
              to="/genres"
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-800"
            >
              Genres
            </Link>
            <Link
              to="/popular"
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-800"
            >
              Popular
            </Link>
            
            <div className="pt-4 pb-3 border-t border-gray-800">
              <div className="flex items-center justify-between px-3">
                <Link to="/login" className="block">
                  <Button 
                    variant="primary" 
                    size="sm"
                    leftIcon={<User className="h-4 w-4" />}
                  >
                    Sign In
                  </Button>
                </Link>
                
                <div className="flex space-x-3">
                  <button
                    onClick={toggleTheme}
                    className="p-2 rounded-full hover:bg-gray-800 transition-colors"
                    aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
                  >
                    {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  </button>
                  
                  <Link to="/watchlist">
                    <button
                      className="p-2 rounded-full hover:bg-gray-800 transition-colors"
                      aria-label="Watchlist"
                    >
                      <Heart className="h-5 w-5" />
                    </button>
                  </Link>
                  
                  <Link to="/history">
                    <button
                      className="p-2 rounded-full hover:bg-gray-800 transition-colors"
                      aria-label="History"
                    >
                      <Clock className="h-5 w-5" />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};