import React from 'react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AnimeCard } from '../ui/AnimeCard';
import { Anime } from '../../types';

interface AnimeSectionProps {
  title: string;
  animeList: Anime[];
  viewAllLink?: string;
  className?: string;
}

export const AnimeSection: React.FC<AnimeSectionProps> = ({ 
  title, 
  animeList, 
  viewAllLink,
  className = ''
}) => {
  return (
    <section className={`py-10 ${className}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">{title}</h2>
          {viewAllLink && (
            <Link 
              to={viewAllLink}
              className="flex items-center text-sm font-medium text-primary-400 hover:text-primary-300 transition-colors"
            >
              View All
              <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          )}
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {animeList.map(anime => (
            <AnimeCard 
              key={anime.id} 
              anime={anime} 
            />
          ))}
        </div>
      </div>
    </section>
  );
};