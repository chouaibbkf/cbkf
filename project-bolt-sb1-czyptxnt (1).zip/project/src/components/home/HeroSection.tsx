import React, { useState, useEffect } from 'react';
import { Play, Info, ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';
import { Anime } from '../../types';
import { featuredAnime } from '../../data/animeData';

export const HeroSection: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  // Auto slide change
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredAnime.length);
    }, 8000);
    
    return () => clearInterval(interval);
  }, []);
  
  const goToPrevSlide = () => {
    setCurrentSlide((prev) => 
      prev === 0 ? featuredAnime.length - 1 : prev - 1
    );
  };
  
  const goToNextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredAnime.length);
  };

  return (
    <section className="relative h-[80vh] min-h-[550px]">
      {/* Slides */}
      {featuredAnime.map((anime, index) => (
        <div 
          key={anime.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
          }`}
        >
          {/* Background Image with Gradient Overlay */}
          <div className="absolute inset-0">
            <img 
              src={anime.image} 
              alt={anime.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/80 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent" />
          </div>
          
          {/* Content */}
          <div className="relative z-20 h-full container mx-auto px-4 flex items-center">
            <div className="max-w-2xl">
              <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary-500 text-white rounded-full mb-4">
                {anime.type} • {anime.status}
              </span>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 drop-shadow-md">
                {anime.title}
              </h1>
              
              <div className="flex items-center space-x-4 mb-4">
                <div className="px-2.5 py-1 bg-yellow-500 text-gray-900 rounded-md text-sm font-bold">
                  {anime.rating.toFixed(1)}
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-300">{anime.year}</span>
                  <span className="w-1 h-1 rounded-full bg-gray-400"></span>
                  <span className="text-sm text-gray-300">{anime.totalEpisodes} Episodes</span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {anime.genres.map(genre => (
                  <Link 
                    to={`/genre/${genre.toLowerCase()}`} 
                    key={genre}
                    className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-sm rounded-full transition-colors"
                  >
                    {genre}
                  </Link>
                ))}
              </div>
              
              <p className="text-gray-300 mb-6 line-clamp-3 md:line-clamp-4">
                {anime.synopsis}
              </p>
              
              <div className="flex space-x-4">
                <Link to={`/watch/${anime.id}/1`}>
                  <Button leftIcon={<Play className="h-4 w-4" />}>
                    Watch Now
                  </Button>
                </Link>
                <Link to={`/anime/${anime.id}`}>
                  <Button variant="outline" leftIcon={<Info className="h-4 w-4" />}>
                    Details
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      ))}
      
      {/* Navigation Controls */}
      <div className="absolute left-0 right-0 bottom-10 z-30 flex justify-center space-x-2">
        {featuredAnime.map((_, index) => (
          <button 
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              index === currentSlide 
                ? 'bg-primary-500 w-8' 
                : 'bg-gray-500 hover:bg-gray-400'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
      
      {/* Prev/Next Buttons */}
      <button 
        onClick={goToPrevSlide}
        className="absolute left-4 top-1/2 z-30 transform -translate-y-1/2 w-10 h-10 flex items-center justify-center rounded-full bg-gray-800/50 hover:bg-gray-800 transition-colors"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>
      <button 
        onClick={goToNextSlide}
        className="absolute right-4 top-1/2 z-30 transform -translate-y-1/2 w-10 h-10 flex items-center justify-center rounded-full bg-gray-800/50 hover:bg-gray-800 transition-colors"
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </button>
    </section>
  );
};