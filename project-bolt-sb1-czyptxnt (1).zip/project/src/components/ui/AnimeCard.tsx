import React from 'react';
import { Star, Clock } from 'lucide-react';
import { Anime } from '../../types';
import { Link } from 'react-router-dom';

interface AnimeCardProps {
  anime: Anime;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const AnimeCard: React.FC<AnimeCardProps> = ({ 
  anime, 
  className = '',
  size = 'md'
}) => {
  const { id, title, image, rating, year, type, genres } = anime;
  
  const sizeClasses = {
    sm: 'w-40',
    md: 'w-56',
    lg: 'w-72'
  };

  return (
    <Link 
      to={`/anime/${id}`}
      className={`card group ${sizeClasses[size]} ${className}`}
    >
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full aspect-[3/4] object-cover transition-transform duration-300 group-hover:scale-110" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
            <span className="text-sm font-medium">{rating.toFixed(1)}</span>
          </div>
          <div className="flex items-center space-x-2 mb-1">
            <Clock className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-300">{year}</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-1">
            {genres.slice(0, 2).map(genre => (
              <span key={genre} className="text-xs px-2 py-0.5 bg-gray-800 rounded-full">
                {genre}
              </span>
            ))}
          </div>
        </div>
        
        <div className="absolute top-2 right-2">
          <span className="px-2 py-1 text-xs font-bold bg-primary-600 rounded-md">
            {type}
          </span>
        </div>
        
        {anime.status === "Ongoing" && (
          <div className="absolute top-2 left-2">
            <span className="px-2 py-1 text-xs font-bold bg-accent-600 rounded-md">
              {anime.status}
            </span>
          </div>
        )}
      </div>
      
      <div className="p-3">
        <h3 className="font-semibold text-gray-100 line-clamp-2 h-12">{title}</h3>
      </div>
    </Link>
  );
};