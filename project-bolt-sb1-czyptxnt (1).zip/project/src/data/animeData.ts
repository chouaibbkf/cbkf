import { Anime } from "../types";

export const featuredAnime: Anime[] = [
  {
    id: 1,
    title: "Demon Slayer: Kimetsu no Yaiba",
    image: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.9,
    year: 2019,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Fantasy", "Historical", "Shounen"],
    synopsis: "Tanjiro Kamado and his friends from the Demon Slayer Corps continue their mission to defeat demons and protect humanity from their threat.",
    totalEpisodes: 26,
  },
  {
    id: 2,
    title: "Attack on Titan",
    image: "https://images.pexels.com/photos/12318159/pexels-photo-12318159.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 9.2,
    year: 2013,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Drama", "Fantasy", "Mystery"],
    synopsis: "In a world where humanity lives within cities surrounded by enormous walls that protect them from gigantic man-eating humanoids, a young boy vows to destroy them after a titan brings tragedy upon his home.",
    totalEpisodes: 87,
  },
  {
    id: 3,
    title: "Jujutsu Kaisen",
    image: "https://images.pexels.com/photos/14554258/pexels-photo-14554258.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.7,
    year: 2020,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Supernatural", "School", "Shounen"],
    synopsis: "A boy swallows a cursed talisman - the finger of a demon - and becomes cursed himself. He enters a shaman school to be able to locate the demon's other body parts and thus exorcise himself.",
    totalEpisodes: 24,
  },
  {
    id: 4,
    title: "My Hero Academia",
    image: "https://images.pexels.com/photos/5490266/pexels-photo-5490266.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.4,
    year: 2016,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Comedy", "Super Power", "School"],
    synopsis: "A superhero-loving boy without any powers enrolls in a prestigious hero academy and learns what it really means to be a hero.",
    totalEpisodes: 113,
  }
];

export const popularAnime: Anime[] = [
  {
    id: 5,
    title: "One Piece",
    image: "https://images.pexels.com/photos/9956943/pexels-photo-9956943.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.7,
    year: 1999,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Adventure", "Comedy", "Fantasy"],
    synopsis: "Follows the adventures of Monkey D. Luffy and his pirate crew in order to find the greatest treasure ever left by the legendary Pirate, Gold Roger.",
    totalEpisodes: 1000,
  },
  {
    id: 6,
    title: "Naruto: Shippuden",
    image: "https://images.pexels.com/photos/8200614/pexels-photo-8200614.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.6,
    year: 2007,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Adventure", "Comedy", "Martial Arts"],
    synopsis: "Naruto Uzumaki, is a loud, hyperactive, adolescent ninja who constantly searches for approval and recognition, as well as to become Hokage, who is acknowledged as the leader and strongest of all ninja in the village.",
    totalEpisodes: 500,
  },
  {
    id: 7,
    title: "Death Note",
    image: "https://images.pexels.com/photos/13455799/pexels-photo-13455799.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 9.0,
    year: 2006,
    type: "TV",
    status: "Completed",
    genres: ["Mystery", "Psychological", "Supernatural", "Thriller"],
    synopsis: "An intelligent high school student goes on a secret crusade to eliminate criminals from the world after discovering a notebook capable of killing anyone whose name is written into it.",
    totalEpisodes: 37,
  },
  {
    id: 8,
    title: "Fullmetal Alchemist: Brotherhood",
    image: "https://images.pexels.com/photos/12789687/pexels-photo-12789687.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 9.1,
    year: 2009,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Adventure", "Drama", "Fantasy"],
    synopsis: "Two brothers search for a Philosopher's Stone after an attempt to revive their deceased mother goes wrong and leaves them in damaged physical forms.",
    totalEpisodes: 64,
  }
];

export const recentlyAddedAnime: Anime[] = [
  {
    id: 9,
    title: "Chainsaw Man",
    image: "https://images.pexels.com/photos/15865669/pexels-photo-15865669/free-photo-of-anime-figure.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.8,
    year: 2022,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Horror", "Supernatural", "Gore"],
    synopsis: "Following a betrayal, a young man left for dead is reborn as a powerful devil-human hybrid after merging with his pet devil and is soon enlisted into an organization dedicated to hunting devils.",
    totalEpisodes: 12,
  },
  {
    id: 10,
    title: "Spy x Family",
    image: "https://images.pexels.com/photos/16444739/pexels-photo-16444739/free-photo-of-naruto.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.6,
    year: 2022,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Comedy", "Slice of Life"],
    synopsis: "A spy on an undercover mission gets married and adopts a child as part of his cover. His wife and daughter have secrets of their own, and all three must strive to keep together.",
    totalEpisodes: 25,
  },
  {
    id: 11,
    title: "Vinland Saga",
    image: "https://images.pexels.com/photos/15865638/pexels-photo-15865638/free-photo-of-anime-collectible-figure.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.8,
    year: 2019,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Adventure", "Drama", "Historical"],
    synopsis: "Thorfinn pursues a journey with his father's killer in order to take revenge and end his life in a duel as an honorable warrior and pay his father a homage.",
    totalEpisodes: 48,
  },
  {
    id: 12,
    title: "Tokyo Revengers",
    image: "https://images.pexels.com/photos/15865670/pexels-photo-15865670/free-photo-of-anime-figure.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.3,
    year: 2021,
    type: "TV",
    status: "Ongoing",
    genres: ["Action", "Drama", "Supernatural"],
    synopsis: "Takemichi Hanagaki is a freelancer that's reached the absolute pits of despair in his life when he finds out that the only girlfriend he ever had, in middle school, Hinata Tachibana, had been killed by the Tokyo Manji Gang.",
    totalEpisodes: 24,
  }
];

// Full anime detail with episodes
export const animeDetails: Record<number, Anime> = {
  1: {
    id: 1,
    title: "Demon Slayer: Kimetsu no Yaiba",
    image: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    rating: 8.9,
    year: 2019,
    type: "TV",
    status: "Completed",
    genres: ["Action", "Fantasy", "Historical", "Shounen"],
    synopsis: "Tanjiro Kamado and his friends from the Demon Slayer Corps continue their mission to defeat demons and protect humanity from their threat.",
    episodes: [
      {
        id: 101,
        number: 1,
        title: "Cruelty",
        thumbnail: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
        duration: "23:40",
        releaseDate: "2019-04-06"
      },
      {
        id: 102,
        number: 2,
        title: "Trainer Sakonji Urokodaki",
        thumbnail: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
        duration: "23:40",
        releaseDate: "2019-04-13"
      },
      {
        id: 103,
        number: 3,
        title: "Sabito and Makomo",
        thumbnail: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
        duration: "23:40",
        releaseDate: "2019-04-20"
      }
    ],
    totalEpisodes: 26,
    related: [
      {
        id: 21,
        title: "Demon Slayer: Mugen Train",
        image: "https://images.pexels.com/photos/6447217/pexels-photo-6447217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
        relation: "Sequel"
      }
    ]
  },
  // Add more detailed anime entries as needed
};