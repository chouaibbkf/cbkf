export interface Anime {
  id: number;
  title: string;
  image: string;
  rating: number;
  year: number;
  type: "TV" | "Movie" | "OVA";
  status: "Ongoing" | "Completed";
  genres: string[];
  synopsis: string;
  episodes?: Episode[];
  totalEpisodes?: number;
  related?: RelatedAnime[];
}

export interface Episode {
  id: number;
  number: number;
  title: string;
  thumbnail: string;
  duration: string;
  releaseDate: string;
}

export interface RelatedAnime {
  id: number;
  title: string;
  image: string;
  relation: "Sequel" | "Prequel" | "Side Story" | "Alternative Version" | "Other";
}

export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  watchlist: number[];
  history: {
    animeId: number;
    episodeId: number;
    timestamp: number;
    lastWatched: string;
  }[];
}