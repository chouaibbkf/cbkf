import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { AnimeSection } from '../components/home/AnimeSection';
import { featuredAnime, popularAnime, recentlyAddedAnime } from '../data/animeData';

const HomePage: React.FC = () => {
  return (
    <div>
      <HeroSection />
      
      <AnimeSection 
        title="Popular Anime"
        animeList={popularAnime}
        viewAllLink="/popular"
      />
      
      <AnimeSection 
        title="Recently Added"
        animeList={recentlyAddedAnime}
        viewAllLink="/recent"
        className="bg-gray-900"
      />
      
      <div className="bg-gradient-radial from-primary-900/30 via-gray-950 to-gray-950 py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Watch Anime Anytime, Anywhere</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">
            AniBKF brings you the latest and greatest anime from Japan. Sign up today for a personalized anime watching experience.
          </p>
          <button className="btn-primary">Sign Up Now</button>
        </div>
      </div>
    </div>
  );
};

export default HomePage;