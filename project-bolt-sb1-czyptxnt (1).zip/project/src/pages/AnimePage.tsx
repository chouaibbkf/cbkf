import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Calendar, Clock, Play, Heart, Share2, Plus } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { EpisodeList } from '../components/anime/EpisodeList';
import { AnimeCard } from '../components/ui/AnimeCard';
import { animeDetails } from '../data/animeData';

const AnimePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const animeId = parseInt(id || '1');
  const anime = animeDetails[animeId];
  
  if (!anime) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Anime Not Found</h1>
          <p className="text-gray-400 mb-6">The anime you're looking for doesn't exist or has been removed.</p>
          <Link to="/">
            <Button>Return Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero Banner */}
      <div className="relative h-[50vh] min-h-[400px]">
        <div className="absolute inset-0">
          <img 
            src={anime.image} 
            alt={anime.title} 
            className="w-full h-full object-cover" 
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent" />
        </div>
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="w-48 md:w-64 flex-shrink-0 mx-auto md:mx-0">
            <div className="relative rounded-lg overflow-hidden shadow-xl">
              <img 
                src={anime.image} 
                alt={anime.title} 
                className="w-full aspect-[3/4] object-cover" 
              />
              <div className="absolute top-2 right-2">
                <div className="px-2 py-1 text-xs font-bold bg-primary-600 rounded-md">
                  {anime.type}
                </div>
              </div>
            </div>
            
            <div className="mt-4 space-y-3">
              <Button 
                variant="primary" 
                leftIcon={<Play className="h-4 w-4" />}
                className="w-full"
              >
                Watch Now
              </Button>
              
              <Button 
                variant="outline" 
                leftIcon={<Plus className="h-4 w-4" />}
                className="w-full"
              >
                Add to Watchlist
              </Button>
            </div>
          </div>
          
          {/* Details */}
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-3">{anime.title}</h1>
            
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mb-4">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                <span className="font-medium">{anime.rating.toFixed(1)}</span>
              </div>
              
              <div className="flex items-center">
                <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                <span className="text-gray-300">{anime.year}</span>
              </div>
              
              <div className="flex items-center">
                <Clock className="h-4 w-4 text-gray-400 mr-1" />
                <span className="text-gray-300">{anime.totalEpisodes} Episodes</span>
              </div>
              
              <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                anime.status === "Ongoing" 
                  ? "bg-accent-600 text-white" 
                  : "bg-green-600 text-white"
              }`}>
                {anime.status}
              </span>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {anime.genres.map(genre => (
                <Link 
                  to={`/genre/${genre.toLowerCase()}`} 
                  key={genre}
                  className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-sm rounded-full transition-colors"
                >
                  {genre}
                </Link>
              ))}
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg mb-8">
              <h3 className="text-lg font-semibold mb-2">Synopsis</h3>
              <p className="text-gray-300">{anime.synopsis}</p>
            </div>
            
            <div className="flex space-x-4 mb-8">
              <button className="flex items-center text-gray-300 hover:text-white transition-colors">
                <Heart className="h-5 w-5 mr-2" />
                Add to Favorites
              </button>
              <button className="flex items-center text-gray-300 hover:text-white transition-colors">
                <Share2 className="h-5 w-5 mr-2" />
                Share
              </button>
            </div>
            
            {/* Episodes */}
            {anime.episodes && (
              <EpisodeList 
                animeId={anime.id} 
                episodes={anime.episodes} 
                className="mb-8"
              />
            )}
            
            {/* Related Anime */}
            {anime.related && anime.related.length > 0 && (
              <div className="mb-8">
                <h3 className="text-xl font-bold mb-4">Related Anime</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {anime.related.map(related => (
                    <Link 
                      key={related.id}
                      to={`/anime/${related.id}`}
                      className="block"
                    >
                      <div className="bg-gray-800 rounded-lg overflow-hidden">
                        <img 
                          src={related.image} 
                          alt={related.title} 
                          className="w-full aspect-video object-cover" 
                        />
                        <div className="p-3">
                          <h4 className="font-medium text-sm">{related.title}</h4>
                          <span className="text-xs text-gray-400">{related.relation}</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnimePage;