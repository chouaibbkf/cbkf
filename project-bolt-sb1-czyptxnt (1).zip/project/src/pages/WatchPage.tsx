import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Heart, Share2 } from 'lucide-react';
import { VideoPlayer } from '../components/anime/VideoPlayer';
import { animeDetails } from '../data/animeData';

const WatchPage: React.FC = () => {
  const { animeId, episodeNumber } = useParams<{ animeId: string, episodeNumber: string }>();
  const animeIdNum = parseInt(animeId || '1');
  const episodeNum = parseInt(episodeNumber || '1');
  
  const anime = animeDetails[animeIdNum];
  
  if (!anime) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Anime Not Found</h1>
          <p className="text-gray-400 mb-6">The anime you're looking for doesn't exist or has been removed.</p>
          <Link to="/">
            <button className="btn-primary">Return Home</button>
          </Link>
        </div>
      </div>
    );
  }
  
  const episode = anime.episodes?.find(ep => ep.number === episodeNum);
  
  if (!episode) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Episode Not Found</h1>
          <p className="text-gray-400 mb-6">The episode you're looking for doesn't exist or has been removed.</p>
          <Link to={`/anime/${animeId}`}>
            <button className="btn-primary">Return to Anime</button>
          </Link>
        </div>
      </div>
    );
  }

  const hasNextEpisode = anime.episodes && anime.episodes.some(ep => ep.number === episodeNum + 1);
  
  const handleNextEpisode = () => {
    // Navigate to next episode
    window.location.href = `/watch/${animeId}/${episodeNum + 1}`;
  };

  return (
    <div className="pt-16 pb-10">
      <div className="container mx-auto px-4">
        <Link 
          to={`/anime/${animeId}`}
          className="inline-flex items-center text-gray-400 hover:text-white mb-4 transition-colors"
        >
          <ChevronLeft className="h-5 w-5 mr-1" />
          Back to Anime Details
        </Link>
        
        <VideoPlayer 
          src={episode.thumbnail}
          title={anime.title}
          episodeNumber={episode.number}
          episodeTitle={episode.title}
          onNextEpisode={hasNextEpisode ? handleNextEpisode : undefined}
          className="w-full aspect-video mb-6"
        />
        
        <div className="mb-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold mb-1">{anime.title}</h1>
              <h2 className="text-xl text-gray-300 mb-4">
                Episode {episode.number} - {episode.title}
              </h2>
            </div>
            
            <div className="flex space-x-4">
              <button className="flex items-center text-gray-300 hover:text-white transition-colors">
                <Heart className="h-5 w-5 mr-2" />
                Favorite
              </button>
              <button className="flex items-center text-gray-300 hover:text-white transition-colors">
                <Share2 className="h-5 w-5 mr-2" />
                Share
              </button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {anime.genres.map(genre => (
              <Link 
                to={`/genre/${genre.toLowerCase()}`} 
                key={genre}
                className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-sm rounded-full transition-colors"
              >
                {genre}
              </Link>
            ))}
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-2">Episode Information</h3>
            <p className="text-gray-300">
              Released on {episode.releaseDate} • {episode.duration}
            </p>
            <p className="mt-4 text-gray-300">
              {/* In a real implementation, this would be episode-specific description */}
              This episode continues the exciting journey of our main characters as they face new challenges and enemies.
            </p>
          </div>
        </div>
        
        {/* Episode Navigation */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {episodeNum > 1 && (
            <Link 
              to={`/watch/${animeId}/${episodeNum - 1}`}
              className="p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <div className="flex items-center">
                <ChevronLeft className="h-5 w-5 mr-2" />
                <div>
                  <span className="text-sm text-gray-400">Previous Episode</span>
                  <p className="font-medium">Episode {episodeNum - 1}</p>
                </div>
              </div>
            </Link>
          )}
          
          {hasNextEpisode && (
            <Link 
              to={`/watch/${animeId}/${episodeNum + 1}`}
              className={`p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors ${
                episodeNum === 1 ? 'col-span-2' : ''
              }`}
            >
              <div className="flex items-center justify-end">
                <div className="text-right">
                  <span className="text-sm text-gray-400">Next Episode</span>
                  <p className="font-medium">Episode {episodeNum + 1}</p>
                </div>
                <ChevronLeft className="h-5 w-5 ml-2 rotate-180" />
              </div>
            </Link>
          )}
        </div>
        
        {/* More episodes */}
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">More Episodes</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {anime.episodes?.slice(0, 6).map(ep => (
              <Link 
                key={ep.id}
                to={`/watch/${animeId}/${ep.number}`}
                className={`block p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors ${
                  ep.number === episodeNum ? 'ring-2 ring-primary-500' : ''
                }`}
              >
                <div className="flex items-center">
                  <div className="w-16 h-16 rounded overflow-hidden mr-4 flex-shrink-0">
                    <img 
                      src={ep.thumbnail} 
                      alt={`Episode ${ep.number}`}
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div>
                    <span className="text-sm text-primary-400">Episode {ep.number}</span>
                    <p className="font-medium line-clamp-1">{ep.title}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="mt-4 text-center">
            <Link 
              to={`/anime/${animeId}`}
              className="text-primary-400 hover:text-primary-300 transition-colors"
            >
              View All Episodes
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchPage;