import React, { useState } from 'react';
import { AnimeCard } from '../components/ui/AnimeCard';
import { Button } from '../components/ui/Button';
import { Filter, Search, SlidersHorizontal } from 'lucide-react';
import { featuredAnime, popularAnime, recentlyAddedAnime } from '../data/animeData';

const BrowsePage: React.FC = () => {
  // Combine all anime data for this example
  const allAnime = [...featuredAnime, ...popularAnime, ...recentlyAddedAnime];
  
  // Remove duplicates by id
  const uniqueAnime = Array.from(new Map(allAnime.map(anime => [anime.id, anime])).values());
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // All available genres from our data
  const allGenres = Array.from(
    new Set(uniqueAnime.flatMap(anime => anime.genres))
  ).sort();
  
  const filteredAnime = uniqueAnime.filter(anime => {
    // Search filter
    if (searchQuery && !anime.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Genre filter
    if (selectedGenres.length > 0 && !selectedGenres.some(genre => anime.genres.includes(genre))) {
      return false;
    }
    
    // Type filter
    if (selectedType && anime.type !== selectedType) {
      return false;
    }
    
    // Status filter
    if (selectedStatus && anime.status !== selectedStatus) {
      return false;
    }
    
    return true;
  });
  
  // Sorting
  let sortedAnime = [...filteredAnime];
  if (sortBy === 'rating-desc') {
    sortedAnime.sort((a, b) => b.rating - a.rating);
  } else if (sortBy === 'rating-asc') {
    sortedAnime.sort((a, b) => a.rating - b.rating);
  } else if (sortBy === 'year-desc') {
    sortedAnime.sort((a, b) => b.year - a.year);
  } else if (sortBy === 'year-asc') {
    sortedAnime.sort((a, b) => a.year - b.year);
  } else if (sortBy === 'title-asc') {
    sortedAnime.sort((a, b) => a.title.localeCompare(b.title));
  } else if (sortBy === 'title-desc') {
    sortedAnime.sort((a, b) => b.title.localeCompare(a.title));
  }
  
  const toggleGenre = (genre: string) => {
    setSelectedGenres(prev => 
      prev.includes(genre) 
        ? prev.filter(g => g !== genre)
        : [...prev, genre]
    );
  };
  
  const resetFilters = () => {
    setSearchQuery('');
    setSelectedGenres([]);
    setSelectedType('');
    setSelectedStatus('');
    setSortBy('');
  };
  
  return (
    <div className="min-h-screen pt-20 pb-10">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6">Browse Anime</h1>
        
        {/* Search & Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search anime..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full input pl-10"
              />
            </div>
            
            {/* Sort By */}
            <div className="w-full md:w-48">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="input w-full"
              >
                <option value="">Sort By</option>
                <option value="rating-desc">Rating (High to Low)</option>
                <option value="rating-asc">Rating (Low to High)</option>
                <option value="year-desc">Year (Newest)</option>
                <option value="year-asc">Year (Oldest)</option>
                <option value="title-asc">Title (A-Z)</option>
                <option value="title-desc">Title (Z-A)</option>
              </select>
            </div>
            
            {/* Filter Toggle Button (Mobile) */}
            <div className="md:hidden">
              <Button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                variant="outline"
                leftIcon={<SlidersHorizontal className="h-4 w-4" />}
                className="w-full"
              >
                Filters
              </Button>
            </div>
          </div>
          
          {/* Filters (Desktop always visible, Mobile toggleable) */}
          <div className={`mt-4 bg-gray-900 rounded-lg p-4 ${isFilterOpen ? 'block' : 'hidden md:block'}`}>
            <div className="flex flex-col md:flex-row gap-6">
              {/* Types */}
              <div className="flex-1">
                <h3 className="font-medium mb-2 flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Type
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {['TV', 'Movie', 'OVA'].map(type => (
                    <label key={type} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="type"
                        checked={selectedType === type}
                        onChange={() => setSelectedType(prev => prev === type ? '' : type)}
                        className="text-primary-500 focus:ring-primary-500"
                      />
                      <span>{type}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              {/* Status */}
              <div className="flex-1">
                <h3 className="font-medium mb-2">Status</h3>
                <div className="grid grid-cols-2 gap-2">
                  {['Ongoing', 'Completed'].map(status => (
                    <label key={status} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="status"
                        checked={selectedStatus === status}
                        onChange={() => setSelectedStatus(prev => prev === status ? '' : status)}
                        className="text-primary-500 focus:ring-primary-500"
                      />
                      <span>{status}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              {/* Genres */}
              <div className="flex-1">
                <h3 className="font-medium mb-2">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {allGenres.map(genre => (
                    <button
                      key={genre}
                      onClick={() => toggleGenre(genre)}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        selectedGenres.includes(genre)
                          ? 'bg-primary-500 text-white'
                          : 'bg-gray-800 hover:bg-gray-700 text-gray-200'
                      }`}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Button
                onClick={resetFilters}
                variant="outline"
                size="sm"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </div>
        
        {/* Results */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">
              Results <span className="text-gray-400">({sortedAnime.length})</span>
            </h2>
          </div>
          
          {sortedAnime.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
              {sortedAnime.map(anime => (
                <AnimeCard 
                  key={anime.id} 
                  anime={anime} 
                />
              ))}
            </div>
          ) : (
            <div className="bg-gray-900 rounded-lg p-8 text-center">
              <h3 className="text-xl font-semibold mb-2">No results found</h3>
              <p className="text-gray-400 mb-4">Try adjusting your filters or search query</p>
              <Button onClick={resetFilters}>Reset Filters</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BrowsePage;